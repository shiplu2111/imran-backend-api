<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Message extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'email',
        'subject',
        'message',
        'date',
        'is_read',
        'status'
    ];

    protected $casts = [
        'is_read' => 'boolean',
        'date' => 'date:Y-m-d',
    ];
}
